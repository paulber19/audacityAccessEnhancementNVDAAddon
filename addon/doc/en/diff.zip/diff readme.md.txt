readme.md
This file should not be translated.
diff between version 3.0.2 (<) and version 3.1 (>)
10c10
< 	* Last NVDA version tested:  2023.3
---
> 	* Last NVDA version tested:  2024.1
33c33
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.0.2.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.1.nvda-addon
