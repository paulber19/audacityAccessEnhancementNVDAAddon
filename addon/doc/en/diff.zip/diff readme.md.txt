readme.md
This file should not be translated.
diff between version 3.1.1 (<) and version 3.2 (>)
10c10
< 	* Last NVDA version tested:  2024.1
---
> 	* Last NVDA version tested:  2024.4
29c29
< This addon's version has been tested with audacity 3.4, 3.4.2, 3.3.0 and 3.3.3.
---
> This addon's version has been tested with audacity 3.6.4 x64, 3.6.2 x64, 3.5.1 x64, 3.4.2 x64,  3.3.3 and 3.3.0.
33c33
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.1.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.2.nvda-addon
