readme.md
diff between version 2.9 (<) and version 3.0 (>)
This file should not be translated.
9,10c9,10
< 	* Minimum required NVDA version:  2020.4
< 	* Last NVDA version tested:  2023.1
---
> 	* Minimum required NVDA version:  2022.1
> 	* Last NVDA version tested:  2023.3
16c16
< * a script to report start and end of selection,
---
> * a script to report time spin boxes of selection,
20c20
< * timer control editting support,
---
> * time edit spin box editting support,
29,30c29,30
< This addon's version has been tested with audacity 3.2, 3.1, 3.0.
< Previous versions of Audacity are not  supported.
---
> This addon's version has been tested with audacity 3.4, 3.4.2, 3.3.0 and 3.3.3.
> Prior  versions of Audacity are not  supported by this version.
33c33
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-2.9.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-3.0.nvda-addon
