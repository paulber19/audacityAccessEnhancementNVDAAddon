diff between version 2.8 (<) and version 2.9 (>):

33c33
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-2.8.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-2.9.nvda-addon
