readme.md
diff between version 2.7.1 (<) and version 2.8 (>)
This file should not be translated.

10c10
< 	* Last NVDA version tested:  2022.3
---
> 	* Last NVDA version tested:  2023.1
29c29
< Compatible and Tested with Audacity  3.1, 3.0 and 2.4.2. Previous versions of Audacity are not supported.
---
> Compatible and Tested with Audacity  3.2, 3.1, 3.0. Previous versions of Audacity are not supported.
31c31
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-2.7.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/audacityAccessEnhancement/audacityAccessEnhancement-2.8.nvda-addon
